package krpq.util;

public class Refercence {

	  public static final String MODID = "krpq";
	    public static final String NAME = "Kamen Rider Pixel Quest";
	    public static final String VERSION = "1.0";
	    public static final String ACCEPTED_VERSIONS = "[1.12.2]";
	    
	    public static final String CLIENT_PROXY_CLASS = "krpq.ClientProxyRider";
	    public static final String COMMON_PROXY_CLASS = "krpq.CommonProxyRider";

}
