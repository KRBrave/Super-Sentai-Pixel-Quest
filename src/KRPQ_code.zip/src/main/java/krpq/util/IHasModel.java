package krpq.util;

public interface IHasModel 
{
	public void registerModels();
	
}
