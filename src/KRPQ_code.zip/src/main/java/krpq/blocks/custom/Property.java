package krpq.blocks.custom;

public enum Property {
    TRANSPARENT,
    FALLING, WALKTHROUGH
}
