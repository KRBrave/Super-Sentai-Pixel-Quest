package sspq.blocks.custom;

public enum Property {
    TRANSPARENT,
    FALLING, WALKTHROUGH
}
