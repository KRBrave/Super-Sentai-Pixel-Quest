package sspq.util;

public interface IHasModel 
{
	public void registerModels();
	
}
