package sspq.util;

public class Refercence {

	  public static final String MODID = "sspq";
	    public static final String NAME = "Super Sentai Pixel Quest";
	    public static final String VERSION = "1.12.2";
	    public static final String ACCEPTED_VERSIONS = "[1.12.2]";
	    
	    public static final String CLIENT_PROXY_CLASS = "sspq.ClientProxyRider";
	    public static final String COMMON_PROXY_CLASS = "sspq.CommonProxyRider";

}
