package sspq;

import com.jcraft.jorbis.Block;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.network.NetworkRegistry;

public class CommonProxyRider
{
	
    public void registerRenderThings() { }

	public void registerItemRender(Item item, int i, String string) { }

	public void registerblockRender(Block ore_block, int i, String string) { }

	public void preInit() {
		
	}
}